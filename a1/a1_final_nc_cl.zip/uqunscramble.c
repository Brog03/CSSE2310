#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <csse2310a1.h>

#define MAX_BUFFER_LENGTH 60

#define ERROR10                                                                \
    "Usage: uqunscramble [--lett chars]"                                       \
    " [--min-length numletters] [--dict filename]\n"

#define ERROR4                                                                 \
    "uqunscramble: minimum length"                                             \
    " must be between 3 and 5\n"

#define ERROR16 "uqunscramble: letter set is invalid\n"

#define ERROR18 "uqunscramble: too many letters - at most 13 expected\n"

#define ERROR11                                                                \
    "uqunscramble: more letters required for the"                              \
    " given minimum length (%d)\n"

#define ERROR17                                                                \
    "uqunscramble: dictionary with name"                                       \
    " \"%s\" cannot be opened\n"

struct Dictionary {
    char** ptr;
    int length;
    int maxScore;
};

struct PrsArgv {
    char letters[MAX_BUFFER_LENGTH];
    FILE* filePtr;
    int minLength;
    int errorStatus;
};

bool wordOnlyContainsLetterSet(char* word, char* letters);
bool wordIsChar(char* word);
void intialiseDict(struct Dictionary* dict, struct PrsArgv* newArgv);
void freeDict(struct Dictionary* dict);
int validateWord(struct Dictionary* dict, char* word, char* letters);
int wordInDict(char** dictPtr, char* word, int dictLength);
bool strcmpCis(char* word1, char* word2);
void checkArgv(int argc, char** argv, struct PrsArgv* newArgv);
bool wordIsDigit(char* word);
void printDict(struct Dictionary* dict);

int main(int argc, char* argv[])
{
    srand(time(NULL));
    // printf("test");

    int errorStatus = 0;
    int minLength = 3;
    int lettersLength = 0;

    char letters[14] = "";

    bool gameOver = false;

    struct Dictionary dict;
    struct PrsArgv newArgv = {"", NULL, 3, 0};

    // Checking argv
    checkArgv(argc, argv, &newArgv);
    errorStatus = newArgv.errorStatus;

    if (errorStatus != 0) {

        if (errorStatus == 10) {
            fprintf(stderr,
                    "Usage: uqunscramble [--lett chars]"
                    " [--min-length numletters] [--dict filename]\n");
        }

        gameOver = true;

    } else {

        if (strcmp(newArgv.letters, "") == 0) {
            // If the user hasn't used --lett, will generate
            strcpy(letters,
                    get_random_letters((unsigned int)(rand() % (14 - minLength)
                            + minLength)));

            lettersLength = (int)strlen(letters);
        } else {
            strcpy(letters, newArgv.letters);
            lettersLength = (int)strlen(letters);
        }

        strcpy(newArgv.letters, letters);
        minLength = newArgv.minLength;
        intialiseDict(&dict, &newArgv);

        printf("Welcome to UQunscramble!\n");
        printf("Enter words of length %d to %d made from the letters \"%s\"\n",
                minLength, lettersLength, letters);
    }

    char userInput[MAX_BUFFER_LENGTH];
    char* stdinClosed;

    int userInputLength;
    int score = 0;
    int status = 0;

    while (!gameOver) {
        stdinClosed = fgets(userInput, MAX_BUFFER_LENGTH, stdin);
        userInputLength = (int)strlen(userInput);

        if (strcmp(userInput, "q\n") == 0
                || (feof(stdin) && stdinClosed == NULL)) {
            gameOver = true;

            if (strcmp(userInput, "q\n") == 0) {
                printDict(&dict);
                printf("Maximum possible score is %d\n", dict.maxScore);
            }

            if (score == 0) {
                errorStatus = 3;
                printf("No valid guesses\n");
            } else {
                printf("Game over. Your final score is %d\n", score);
            }

            freeDict(&dict);

        } else {

            if (userInput[userInputLength - 1] == '\n') {
                userInputLength -= 1;
                userInput[userInputLength] = '\0';
            } else {
                userInput[userInputLength + 1] = '\0';
            }

            if (!wordIsChar(userInput)) {
                printf("Your guess must contain only letters\n");

            } else if (userInputLength < minLength) {
                printf("Too short! At least %d "
                       "characters are expected\n",
                        minLength);
            } else if (userInputLength > lettersLength) {
                printf("Word must be no more "
                       "than %d characters long\n",
                        lettersLength);

            } else if ((status = validateWord(&dict, userInput, letters))
                    == 3) {
                printf("Word can't be formed from available letters\n");
            } else if (status == 1) {
                printf("Word can't be found in the dictionary file\n");
            } else if (status == 2) {
                printf("You've guessed that word before\n");
            } else {
                score += userInputLength
                        + (userInputLength == lettersLength) * 10;

                printf("OK! Current score is %d\n", score);
            }
        }
    }

    return errorStatus;
}

void checkArgv(int argc, char* argv[], struct PrsArgv* newArgv)
{
    int errorStatus = 0;
    char fileName[MAX_BUFFER_LENGTH] = "/local/courses/csse2310/etc/words";
    bool usage[3] = {false, false, false};

    if (argc != 1 && argc % 2 != 0) {
        for (int i = 1; i < argc; i += 2) {
            if (strcmp("--min-length", argv[i]) == 0 && !usage[0]
                    && wordIsDigit(argv[i + 1])) {

                if (atoi(argv[i + 1]) > 5 || atoi(argv[i + 1]) < 3) {
                    errorStatus = 4;
                    fprintf(stderr, ERROR4);
                    break;
                }

                newArgv->minLength = atoi(argv[i + 1]);
                usage[0] = true;

            } else if (strcmp("--lett", argv[i]) == 0 && !usage[1]) {
                if (!wordIsChar(argv[i + 1])) {
                    errorStatus = 16;
                    fprintf(stderr, ERROR16);
                    break;
                } else if ((int)strlen(argv[i + 1]) > 13) {
                    errorStatus = 18;
                    fprintf(stderr, ERROR18);
                    break;
                } else if ((int)strlen(argv[i + 1]) < newArgv->minLength) {
                    errorStatus = 11;
                    fprintf(stderr, ERROR11, newArgv->minLength);
                    break;
                }

                strcpy(newArgv->letters, argv[i + 1]);
                usage[1] = true;

            } else if (strcmp("--dict", argv[i]) == 0 && !usage[2]) {
                strcpy(fileName, argv[i + 1]);
                usage[2] = true;

            } else {
                errorStatus = 10;
                break;
            }
        }

    } else if (argc != 1) {
        errorStatus = 10;
    }

    newArgv->filePtr = fopen(fileName, "r");

    if (newArgv->filePtr == NULL) {
        errorStatus = 17;
        fprintf(stderr, ERROR17, fileName);
    }

    newArgv->errorStatus = errorStatus;
}

bool wordOnlyContainsLetterSet(char* word, char* letters)
{
    bool status = true;

    int lettersLength = (int)strlen(letters);
    int wordLength = (int)strlen(word);

    char lettersTemp[lettersLength];
    strcpy(lettersTemp, letters);

    if (lettersLength < wordLength) {
        status = false;
    } else {
        int counter = 0;

        for (int i = 0; i < wordLength; i++) {
            for (int j = 0; j < lettersLength; j++) {
                if (tolower(word[i]) == tolower(lettersTemp[j])) {
                    lettersTemp[j] = '0';
                    counter++;
                    break;
                }
            }
        }

        if (counter != wordLength) {
            status = false;
        }
    }

    return status;
}

bool wordIsChar(char* word)
{
    for (int i = 0; i < (int)strlen(word); i++) {
        if (!isalpha(word[i])) {
            return false;
        }
    }
    return true;
}

bool wordIsDigit(char* word)
{
    for (int i = 0; i < (int)strlen(word); i++) {
        if (!isdigit(word[i])) {
            return false;
        }
    }
    return true;
}

void intialiseDict(struct Dictionary* dict, struct PrsArgv* newArgv)
{
    char** dictPtr = malloc(sizeof(char*));

    char buffer[MAX_BUFFER_LENGTH];
    int wordCount = 0;
    int maxScore = 0;
    int bufferLength;
    int lettersLength = (int)strlen(newArgv->letters);

    while (fgets(buffer, MAX_BUFFER_LENGTH, newArgv->filePtr) != NULL) {
        bufferLength = (int)strlen(buffer) - 1;
        buffer[bufferLength] = '\0';

        if (wordOnlyContainsLetterSet(buffer, newArgv->letters)
                && (bufferLength >= newArgv->minLength)
                && (wordInDict(dictPtr, buffer, wordCount) == -1)) {

            if (wordCount != 0) {
                dictPtr = realloc(dictPtr, sizeof(char*) * (wordCount + 1));
            }

            dictPtr[wordCount] = malloc(sizeof(char) * (bufferLength + 2));
            strcpy(dictPtr[wordCount], buffer);

            for (int i = 0; i < bufferLength; i++) {
                dictPtr[wordCount][i] = toupper(dictPtr[wordCount][i]);
            }

            maxScore += (bufferLength + 10 * (bufferLength == lettersLength));
            wordCount++;
        }

        memset(buffer, '\0', MAX_BUFFER_LENGTH * sizeof(char));
    }

    fclose(newArgv->filePtr);

    dict->ptr = dictPtr;
    dict->length = wordCount;
    dict->maxScore = maxScore;
}

void freeDict(struct Dictionary* dict)
{
    for (int i = 0; i < dict->length; i++) {
        free(dict->ptr[i]);
    }

    free(dict->ptr);
}

int wordInDict(char** dictPtr, char* word, int dictLength)
{
    int wordIndex = -1;

    if (dictLength > 0) {
        for (int i = 0; i < dictLength; i++) {
            if (strcmpCis(dictPtr[i], word)) {
                wordIndex = i;
                break;
            }
        }
    }

    return wordIndex;
}

int validateWord(struct Dictionary* dict, char* word, char* letters)
{
    int status = 0;
    bool wcolBool = wordOnlyContainsLetterSet(word, letters);

    int wordIndex = wordInDict(dict->ptr, word, dict->length);
    int dictWordLength;

    if (wordIndex != -1) {
        dictWordLength = (int)strlen(dict->ptr[wordIndex]);

        if (dict->ptr[wordIndex][dictWordLength + 1] != '!') {
            dict->ptr[wordIndex][dictWordLength + 1] = '!';
        } else {
            status = 2;
        }
    } else {
        if (wcolBool) {
            status = 1;
        } else {
            status = 3;
        }
    }
    return status;
}

bool strcmpCis(char* word1, char* word2)
{
    bool equal = true;

    int word1Length = (int)strlen(word1);
    int word2Length = (int)strlen(word2);

    if (word1Length == word2Length) {
        for (int i = 0; i < word1Length; i++) {
            if (tolower(word1[i]) != tolower(word2[i])) {
                equal = false;
                break;
            }
        }

    } else {
        equal = false;
    }

    return equal;
}

void printDict(struct Dictionary* dict)
{
    char wordi[MAX_BUFFER_LENGTH] = "";
    char wordj[MAX_BUFFER_LENGTH] = "";

    char dictTemp[dict->length][MAX_BUFFER_LENGTH];
    int wordLengthi = 0;
    int wordLengthj = 0;

    for (int i = 0; i < dict->length; i++) {
        strcpy(wordi, dict->ptr[i]);
        wordLengthi = (int)strlen(wordi);

        /*word_length = (int)strlen(dict->ptr[i]):
        memset(dict->ptr[i], 0, sizeof(char)*(word_length+2));*/

        int countb = 0;
        int counta = 0;

        for (int j = 0; j < dict->length; j++) {
            strcpy(wordj, dict->ptr[j]);
            wordLengthj = (int)strlen(wordj);

            if (wordLengthi > wordLengthj) {
                countb += 1;
            } else if (wordLengthi == wordLengthj) {
                for (int k = 0; k < wordLengthj; k++) {

                    if (wordi[k] < wordj[k]) {
                        // printf("wordi: %s, is lower wordj: %s\n", wordi,
                        // wordj);
                        break;
                    } else if (wordi[k] > wordj[k]) {
                        counta += 1;
                        break;
                    }
                }
            }
        }

        strcpy(dictTemp[counta + countb], wordi);
    }

    for (int i = 0; i < dict->length; i++) {
        printf("%s\n", dictTemp[i]);
    }
}
