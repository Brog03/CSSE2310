#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <csse2310a1.h>

struct Dictionary {
    char** ptr;
    int length;
    int max_score;
};

struct PrsArgv {
    char letters[50];
    FILE* file_ptr;
    int min_length;
    int error_status;
};

bool word_only_contains_letterset(char* word, char* letters_temp); 
bool word_is_char(char* word); 
void intialise_dict(struct Dictionary *dict, struct PrsArgv *new_argv);
void free_dict(struct Dictionary *dict);
int validate_word(struct Dictionary *dict, char* word, char* letters);
int word_in_dict(char** dict_ptr, char* word, int dict_length);
bool strcmp_cis(char* word1_temp, char* word2_temp);
void check_args(int argc, char** argv, struct PrsArgv *new_argv);
bool word_is_digit(char* word);
void print_dict(struct Dictionary *dict);


int main(int argc, char* argv[]) {
    srand(time(NULL));
    
    int error_status = 0;
    int min_length = 3;
    int letters_length = 0; 

    char letters[14] = "";

    bool game_over = false;

    struct Dictionary dict;
    struct PrsArgv new_argv = {"", NULL, 3, 0};

            
    // If the iccorect number of arguments have been given or an argument
    // is not entered in correctly, an error message will display

    check_args(argc, argv, &new_argv);
    error_status = new_argv.error_status;

    if (error_status != 0) {
        
        if (error_status == 10) {
            fprintf(stderr, "Usage: uqunscramble [--lett chars]" 
                            " [--min-length numletters] [--dict filename]\n");
        } 
        
        game_over = true;

    } else {

        if (strcmp(new_argv.letters, "") == 0) {
            strcpy(letters, get_random_letters(
                        (unsigned int) (rand()%(14-min_length) + min_length)));

            letters_length = (int)strlen(letters);
        } else {
            strcpy(letters, new_argv.letters);
            letters_length = (int)strlen(letters);
        }

        strcpy(new_argv.letters, letters);
        min_length = new_argv.min_length;
        intialise_dict(&dict, &new_argv);


        printf("Welcome to UQunscramble!\n");
        printf("Enter words of length %d to %d made from the letters \"%s\"\n",
                min_length, letters_length, letters);
    }
    
    char user_input[60];
    char* stdin_closed;

    int user_input_length;
    int score = 0;
    int status = 0;

    while (!game_over) {
        memset(user_input,0,strlen(user_input));
        stdin_closed = fgets(user_input, 60, stdin);
        user_input_length = (int)strlen(user_input);


        if (strcmp(user_input, "q\n") == 0 
                || (feof(stdin) && stdin_closed == NULL)) {
            game_over = true;

            if (strcmp(user_input, "q\n") == 0) {
                print_dict(&dict);
                printf("Maximum possible score is %d\n", dict.max_score);
            }


            if (score == 0) {
                error_status = 3;
                printf("No valid guesses\n");
            } else {
                printf("Game over. Your final score is %d\n", score);
            }

            
            free_dict(&dict);

        } else {

            if (user_input[user_input_length-1] == '\n') {
                user_input_length -= 1;
                user_input[user_input_length] = '\0';
            } else {
                user_input[user_input_length + 1] = '\0'; 
            }


            if (!word_is_char(user_input)) {
                printf("Your guess must contain only letters\n");

            } else if (user_input_length < min_length) {
                printf("Too short! At least %d " 
                        "characters are expected\n", min_length);
            } else if (user_input_length > letters_length) {
                printf("Word must be no more " 
                       "than %d characters long\n", letters_length);
            
            } else if ((status = validate_word(&dict, user_input, letters)) == 3) {
                printf("Word can't be formed from available letters\n");
            } else if (status == 1) {
                printf("Word can't be found in the dictionary file\n");
            } else if (status == 2) {
                printf("You've guessed that word before\n");
            } else {
                 score += user_input_length + 
                     (user_input_length == letters_length)*10;
                
                 printf("OK! Current score is %d\n", score);
            }
        }
    }
    
    return error_status;
    
}

void check_args(int argc, char* argv[], struct PrsArgv *new_argv) {
    int error_status = 0;
    char file_name[60] = "/local/courses/csse2310/etc/words";
    bool usage[3] = {false, false, false};


    if (argc != 1 && argc%2 != 0) {
        for (int i = 1; i < argc; i+=2) {
             if (strcmp("--min-length", argv[i]) == 0 
                     && !usage[0] && word_is_digit(argv[i+1])) {

                if (atoi(argv[i+1]) > 5 || atoi(argv[i+1]) < 3) {
                    error_status = 4;
                    fprintf(stderr, "uqunscramble: minimum length" 
                                    " must be between 3 and 5\n");
                    break;
                } 

                new_argv->min_length = atoi(argv[i+1]);
                usage[0] = true;

             } else if (strcmp("--lett", argv[i]) == 0 && !usage[1]) {
                if (!word_is_char(argv[i+1])) {
                    error_status = 16;
                    fprintf(stderr, "uqunscramble: letter set is invalid\n");
                    break;
                } else if ((int)strlen(argv[i+1]) > 13) {
                    error_status = 18;
                    fprintf(stderr, "uqunscramble: too many letters"
                                    " - at most 13 expected\n");
                    break;
                } else if ((int)strlen(argv[i+1]) < new_argv->min_length) {
                    error_status = 11;
                    fprintf(stderr, "uqunscramble: more letters required for" 
                                    " the given minimum length" 
                                    " (%d)\n", new_argv->min_length);
                    break;
                }
                
                strcpy(new_argv->letters, argv[i+1]);
                usage[1] = true;

            } else if (strcmp("--dict", argv[i]) == 0 && !usage[2]) {
                strcpy(file_name, argv[i+1]);
                usage[2] = true;
                
            } else {
                error_status = 10;
                break;
            }   
        }

    } else if (argc != 1) {
        error_status = 10;
    }

    new_argv->file_ptr = fopen(file_name, "r");

    if (new_argv->file_ptr == NULL) {
        error_status = 17;
        fprintf(stderr, "uqunscramble: dictionary with name" 
                        " \"%s\" cannot be opened\n", file_name);
    }

    new_argv->error_status = error_status;

}

bool word_only_contains_letterset(char* word, char* letters_temp) {
    bool status = true;

    int letters_length = (int)strlen(letters_temp);
    int word_length = (int)strlen(word);

    char letters[60];
    strcpy(letters, letters_temp);

    if (letters_length < word_length) {
        status = false;
    } else {
        int counter = 0;

        for (int i = 0; i < word_length; i++) {
            for (int j = 0; j < letters_length; j++) {
                if (tolower(word[i]) == tolower(letters[j]))  {
                    letters[j] = '0';
                    counter++;
                    break;
                }
            }
        }

        if (counter != word_length) {
            status = false;
        }
    }

    return status;
}

bool word_is_char(char* word) {
    for (int i = 0; i < (int)strlen(word); i++) {
        if (!isalpha(word[i])) {
            return false;
        }
    }
    return true;
}

bool word_is_digit(char* word) {
    for (int i = 0; i < (int)strlen(word); i++) {
        if (!isdigit(word[i])) {
            return false;
        }
    }
    return true;
}


void intialise_dict(struct Dictionary *dict, struct PrsArgv *new_argv) {
    char** dict_ptr = malloc(sizeof(char*));

    char buffer[60];
    int word_count = 0;
    int max_score = 0;
    int buffer_length;
    int letters_length = (int)strlen(new_argv->letters);
    
    while (fgets(buffer, 60, new_argv->file_ptr) != NULL) {
        buffer_length = (int)strlen(buffer) - 1;
        buffer[buffer_length] = '\0';

        
        if (word_only_contains_letterset(buffer, new_argv->letters) && 
                (buffer_length >= new_argv->min_length) &&
                (word_in_dict(dict_ptr, buffer, word_count) == -1)) {


            if (word_count != 0) {
                dict_ptr = realloc(dict_ptr, sizeof(char*) * (word_count + 1));
            }

            dict_ptr[word_count] = malloc(sizeof(char) * (buffer_length + 2));
            strcpy(dict_ptr[word_count], buffer);

            for (int i = 0; i < buffer_length; i++) {
                dict_ptr[word_count][i] = toupper(dict_ptr[word_count][i]);
            }

            max_score += (buffer_length + 10*(buffer_length == letters_length));
            word_count++;

        }

        memset(buffer, '\0', 60*sizeof(char));
    }
        
        fclose(new_argv->file_ptr);

        dict->ptr = dict_ptr;
        dict->length = word_count;
        dict->max_score = max_score;
}

void free_dict(struct Dictionary *dict) {
    for (int i = 0; i < dict->length; i++) {
        free(dict->ptr[i]);
    }

    free(dict->ptr);

}

int word_in_dict(char** dict_ptr, char* word, int dict_length) {
    int word_index = -1;

    if (dict_length > 0) {
        for (int i = 0; i < dict_length; i++) {
            if (strcmp_cis(dict_ptr[i], word)) {
                word_index = i;
                break;
            }
        }
    }

    return word_index;
}

int validate_word(struct Dictionary *dict, char* word, char* letters) {
    int status = 0;
    bool word_contains_charset = word_only_contains_letterset(word, letters);

    int word_index = word_in_dict(dict->ptr, word, dict->length);
    int dict_word_length;

    if (word_index != -1) {
        dict_word_length = (int)strlen(dict->ptr[word_index]);
        if (dict->ptr[word_index][dict_word_length + 1] != '!') {
	    dict->ptr[word_index][dict_word_length + 1] = '!';
        } else {
            status = 2;
        }
    } else {
        if (word_contains_charset) {
            status = 1;
        } else {
            status = 3;
        }

    }
    return status;
}

bool strcmp_cis(char* word1, char* word2) {
    bool equal = true;
         
    int word1_length = (int)strlen(word1);
    int word2_length = (int)strlen(word2);

    if (word1_length == word2_length) {
        for (int i = 0; i < word1_length; i++) {
            if (tolower(word1[i]) != tolower(word2[i])) {
                equal = false;
                break;
            }
        }
        
    } else {
        equal = false;
    }

    return equal;
}

void print_dict(struct Dictionary *dict) {
    char word_i[60] = "";
    char word_j[60] = "";
    

    char dict_temp[dict->length][60];
    int word_length_i = 0;
    int word_length_j = 0;

    for (int i = 0; i < dict->length; i++) {
        strcpy(word_i, dict->ptr[i]);
        word_length_i = (int)strlen(word_i);

        /*word_length = (int)strlen(dict->ptr[i]):
        memset(dict->ptr[i], 0, sizeof(char)*(word_length+2));*/

        int count_b = 0;
        int count_a = 0;

        for (int j = 0; j < dict->length; j++) {
            strcpy(word_j, dict->ptr[j]);
            word_length_j = (int)strlen(word_j);


            if (word_length_i > word_length_j) {
                count_b += 1;
            } else if (word_length_i == word_length_j) {
                for (int k = 0; k < word_length_j; k++) {


                    if (word_i[k] < word_j[k]) {
                        //printf("word_i: %s, is lower word_j: %s\n", word_i, word_j);
                        break;
                    } else if (word_i[k] > word_j[k]) {
                        count_a += 1;
                        break;
                    }
                }
            }
        }

        strcpy(dict_temp[count_a + count_b], word_i);

    }

    
    for (int i = 0; i < dict->length; i++) {
        printf("%s\n", dict_temp[i]);
    }
    
}
  
