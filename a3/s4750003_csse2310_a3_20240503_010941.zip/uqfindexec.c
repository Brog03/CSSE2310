#include "inc.h"

#include "pipes.h"
#include "directory.h"
#include "error.h"

#define STDOUT_PERM (S_IWUSR | S_IRUSR)

CommandPipeline* proccess_argv(int argc, char* argv[], struct pArgv* newArgv);
long init_iofp(char* newStdin, char* newStdout, char* currentFile);
int extract_iofp(long fps, int fp);
void redirect_iofp(int newStdinFp, int newStdoutFp, int childNum, int numChild);
void print_stats(int* stats);
void proccess_reap(int** stats, int status, int fileNum);
void calculate_stats(int** stats, int numFiles, int numCmds, int* exitStatus);
int** init_stats(int numFiles);

bool sigc = false;

void signal_handle()
{
    sigc = true;
}

int main(int argc, char* argv[])
{
    struct pArgv newArgv = {"", 0, 0, false, false, false};
    struct sigaction act;
    CommandPipeline* pipeLine = proccess_argv(argc, argv, &newArgv);
    act.sa_handler = signal_handle;
    act.sa_flags = SA_RESTART;
    sigaction(SIGINT, &act, 0);
    int*** allPipes;
    int newStdinFp = 0;
    int newStdoutFp = 0;
    int numFiles = newArgv.numFiles;
    int numCmds = pipeLine->numCmds;
    int numPipes = numCmds - 1;
    int exitStatus = 0;
    int parentData[4];
    int childData[4];
    int** stats = init_stats(numFiles);
    pid_t childPids[numFiles][numCmds];

    if (newArgv.parallel) {
        allPipes = init_pipe_array(numPipes, numFiles);
        memcpy(parentData, PARENT_PARA_DATA, sizeof(PARENT_PARA_DATA));
    } else {
        memcpy(parentData, PARENT_NORM_DATA, sizeof(PARENT_PARA_DATA));
    }

    int status;
    for (int i = 0; i < numFiles; i++) {
        if (sigc) {
            exitStatus = 20;
            if (!newArgv.parallel) {
                continue;
            }
        }

        char* currentFile = newArgv.fileList[i];
        if (!newArgv.parallel) {
            allPipes = init_pipe_array(numPipes, 1);
        }

        char* newStdin = substitute_fileName(
                NULL, pipeLine->stdinFileName, currentFile);
        char* newStdout = substitute_fileName(
                NULL, pipeLine->stdoutFileName, currentFile);
        long fps = init_iofp(newStdin, newStdout, currentFile);

        if ((newStdinFp = extract_iofp(fps, STDIN_FILENO)) == -1
                || (newStdoutFp = extract_iofp(fps, STDOUT_FILENO)) == -1) {
            stats[i][3] += 1;
            free_pipes(allPipes, parentData);
            continue;
        }
        for (int j = 0; j < numCmds; j++) {
            pid_t currentPid;
            char** currentCmd = pipeLine->cmdArray[j];
            fflush(stdout);

            if ((currentPid = fork())) {
                childPids[i][j] = currentPid;

            } else {
                if (newArgv.parallel) {
                    memcpy(childData, CHILD_PARA_DATA, sizeof(CHILD_PARA_DATA));
                } else {
                    memcpy(childData, CHILD_NORM_DATA, sizeof(CHILD_NORM_DATA));
                }
                redirect_iofp(newStdinFp, newStdoutFp, j, numCmds);
                close_pipes(allPipes, childData);
                substitute_fileName(currentCmd, NULL, currentFile);
                execute_command(currentCmd, currentFile);
            }
        }

        if (!newArgv.parallel) {
            close_pipes(allPipes, parentData);
            for (int j = 0; j < numCmds; j++) {
                waitpid(childPids[i][j], &status, 0);
                proccess_reap(stats, status, i);
            }
            free_pipes(allPipes, parentData);
        }
    }

    if (newArgv.parallel) {
        close_pipes(allPipes, parentData);
        for (int i = 0; i < numFiles; i++) {
            for (int j = 0; j < numCmds; j++) {
                waitpid(childPids[i][j], &status, 0);
                proccess_reap(stats, status, i);
            }
        }

        free_pipes(allPipes, parentData);
    }
    
    calculate_stats(stats, numFiles, numCmds, &exitStatus);

    if (newArgv.stats) {
        if (stats != NULL) {
            print_stats(stats[0]);
        } else {
            print_stats(NULL);
        }
    }

    return exitStatus;
}

CommandPipeline* proccess_argv(int argc, char* argv[], struct pArgv* newArgv)
{
    int dirLoc = 0;
    char cmd[200] = "echo {}";
    CommandPipeline* pipeLine;

    for (int i = 1; i < argc; i++) {
        if (strlen(argv[i]) >= 2 && argv[i][0] == '-' && argv[i][1] == '-') {
            if (strcmp(argv[i], "--parallel") == 0 && !newArgv->parallel) {
                newArgv->parallel = true;
            } else if (strcmp(argv[i], "--stats") == 0 && !newArgv->stats) {
                newArgv->stats = true;
            } else if (strcmp(argv[i], "--allfiles") == 0
                    && !newArgv->allfiles) {
                newArgv->allfiles = true;
            } else if (strcmp(argv[i], "--directory") == 0 && !dirLoc
                    && i != argc - 1) {
                strcpy(newArgv->path, argv[i + 1]);
                dirLoc = i + 1;
            } else {
                fprintf(stderr, ERR4_MSG);
                exit(ERR4);
            }
        } else if (i == dirLoc && dirLoc && strlen(argv[i])) {
            strcpy(newArgv->path, argv[i]);
        } else if (i != argc - 1 || !strlen(argv[argc - 1])) {
            fprintf(stderr, ERR4_MSG);
            exit(ERR4);
        } else if (i == argc - 1) {
            strcpy(cmd, argv[i]);
        }
    }

    newArgv->numFiles = read_dir(newArgv);
    pipeLine = parse_pipeline_string(cmd);

    if (pipeLine == NULL) {
        fprintf(stderr, ERR17_MSG);
        exit(ERR17);
    } else {
        return pipeLine;
    }

    return NULL;
}


long init_iofp(char* newStdin, char* newStdout, char* currentFile)
{
    int newStdinFp = 0;
    int newStdoutFp = 0;

    if (newStdin) {
        newStdinFp = open(newStdin, O_RDONLY);

        if (newStdinFp <= 0) {
            fprintf(stderr, ERR_STDIN, newStdin, currentFile);
            newStdinFp = -1;
        }
    }

    if (newStdout) {
        newStdoutFp
                = open(newStdout, O_WRONLY | O_CREAT | O_TRUNC, STDOUT_PERM);

        if (newStdoutFp <= 0) {
            fprintf(stderr, ERR_STDOUT, newStdout, currentFile);
            newStdoutFp = -1;
        }
    }

    return ((long)newStdoutFp << 32) + newStdinFp;
}

int extract_iofp(long fps, int fp)
{
    if (fp == STDIN_FILENO) {
        return fps & 0xFFFFFFFF;
    } else if (fp == STDOUT_FILENO) {
        return (fps & 0xFFFFFFFF00000000) >> 32;
    } else {
        return 0;
    }
}

void redirect_iofp(int newStdinFp, int newStdoutFp, int childNum, int numChild)
{
    if (newStdinFp) {
        if (!childNum) {
            dup2(newStdinFp, STDIN_FILENO);
            close(newStdinFp);
        }
    }

    if (newStdoutFp) {
        if (childNum == (numChild - 1)) {
            dup2(newStdoutFp, STDOUT_FILENO);
            close(newStdoutFp);
        }
    }
}

int** init_stats(int numFiles)
{
    int** stats = NULL;

    if (numFiles > 0) {
        stats = malloc(sizeof(int*) * numFiles);
        for (int i = 0; i < numFiles; i++) {
            stats[i] = malloc(sizeof(int) * 4);
            for (int j = 0; j < 4; j++) {
                stats[i][j] = 0;
            }
        }
    }

    return stats;
}

void proccess_reap(int** stats, int status, int fileNum)
{
    if (stats != NULL) {
        if (WIFEXITED(status)) {
            if (!WEXITSTATUS(status)) {
                stats[fileNum][0] += 1;
            } else if (WEXITSTATUS(status) == 56) {
                stats[fileNum][3] += 1;
            } else {
                stats[fileNum][1] += 1;
            }
        } else if (WIFSIGNALED(status)) {
            stats[fileNum][2] += 1;
        }
    }
}

void calculate_stats(int** stats, int numFiles, int numCmds, int* exitStatus)
{
    if (stats != NULL) {
        int finalStats[4] = {0, 0, 0, 0};
        for (int i = 0; i < numFiles; i++) {
            if (stats[i][2] > 0) {
                finalStats[2] += 1;
            } else if (stats[i][3] > 0) {
                finalStats[3] += 1;
                if (*(exitStatus) == 0) {
                    *(exitStatus) = 15;
                }
            } else if (stats[i][0] == numCmds) {
                finalStats[0] += 1;
            } else if (stats[i][1] < numCmds) {
                finalStats[1] += 1;
            }
        }

        stats[0][0] = finalStats[0];
        stats[0][1] = finalStats[1];
        stats[0][2] = finalStats[2];
        stats[0][3] = finalStats[3];
    }
}

void print_stats(int* stats)
{
    int n2Val;
    int n3Val;
    int n4Val;
    int n5Val;

    if (stats != NULL) {
        n2Val = stats[0];
        n3Val = stats[1];
        n4Val = stats[2];
        n5Val = stats[3];
    } else {
        n2Val = 0;
        n3Val = 0;
        n4Val = 0;
        n5Val = 0;
    }

    int total = n2Val + n3Val + n4Val + n5Val;
    fprintf(stderr, STAT_HEAD, total);
    fprintf(stderr, STAT_N2, n2Val);
    fprintf(stderr, STAT_N3, n3Val);
    fprintf(stderr, STAT_N4, n4Val);
    fprintf(stderr, STAT_N5, n5Val);
}
