#include "inc.h"

#ifndef PIPES_H_
#define PIPES_H_

#define RDFD 0
#define WRFD 1

#define PARENT_PARA_DATA\
    (const int[4]){numPipes, -1, numFiles, -1}

#define PARENT_NORM_DATA\
    (const int[4]){numPipes, -1, 1, -1}

#define CHILD_NORM_DATA\
    (const int[4]){numPipes, j, 1, 0}

#define CHILD_PARA_DATA\
    (const int[4]){numPipes, j, numFiles, i}


int*** init_pipe_array(int numCmds, int numFiles);
void close_pipes(int*** pipes, int data[4]);
void free_pipes(int*** pipes, int data[4]);
void execute_command(char** cmd, char* fileName);

#endif

