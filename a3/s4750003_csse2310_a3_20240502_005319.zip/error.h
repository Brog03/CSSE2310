#ifndef ERROR_H_
#define ERROR_H_

#define ERR12 12
#define ERR12_MSG\
    "uqfindexec: cannot read directory \"%s\"\n"

#define ERR4 4
#define ERR4_MSG\
    "Usage: uqfindexec [--directory dirname] "\
    "[--recurse] [--allfiles] [--parallel] [--stats] [command]\n"

#define ERR17 17
#define ERR17_MSG\
    "uqfindexec: command is invalid\n"

#define ERR_REDIO\
    "uqfindexec: unable to read \"%s\" when processing \"%s\"\n"

#define ERR_EXE\
    "uqfindexec: cannot execute \"%s\" when processing \"%s\"\n"

#define STAT_HEAD\
    "Attempted to process %d files\n"
#define STAT_N2\
    " - processing finished successfully for %d files\n"
#define STAT_N3\
    " - processing may have failed for %d files\n"
#define STAT_N4\
    " - processing terminated by signal for %d files\n"
#define STAT_N5\
    " - processing failed for %d files\n"

#endif

