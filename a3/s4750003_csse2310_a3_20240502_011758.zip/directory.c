#include "directory.h"
#include "error.h"

int read_dir(struct pArgv* newArgv)
{
    // Set the sorting method to emulate ls
    setlocale(LC_COLLATE, "en_AU");
    struct dirent** dir;
    // Scan the directory
    int numFiles;

    if (strlen(newArgv->path)) {
        numFiles = scandir(newArgv->path, &dir, filter, alphasort);
    } else {
        numFiles = scandir(".", &dir, filter, alphasort);
    }
    char** fileList;

    int count = 0;

    if (numFiles > 0) {
        // Assume the directory has 1 file
        fileList = malloc(sizeof(char*));
        for (int i = 0; i < numFiles; i++) {
            char* dirName = dir[i]->d_name;
            // Only adds d_name staring with '.' only if --allfiles was added
            if ((newArgv->allfiles && dirName[0] == '.') || dirName[0] != '.') {
                if (count != 0) {
                    // Adds more space for more files if needed
                    fileList = realloc(fileList, sizeof(char*) * (count + 1));
                }

                fileList[count] = add_path_to_fileName(dirName, newArgv->path);
                count++;
            }
        }

    } else if (numFiles == 0) {
        return 0;
    } else {
        fprintf(stderr, ERR12_MSG, newArgv->path);
        exit(ERR12);
    }

    newArgv->fileList = fileList;

    return count;
}

int filter(const struct dirent* dir)
{
    struct stat slinkStats;
    if (dir->d_type == DT_REG) {
        return 1;
    } else if (dir->d_type == DT_LNK) {
        stat(dir->d_name, &slinkStats);
        if (!S_ISLNK(slinkStats.st_mode)) {
            lstat(dir->d_name, &slinkStats);
            if (!S_ISREG(slinkStats.st_mode)) {
                return 1;
            }
        }
    }

    return 0;
}

char* add_path_to_fileName(char* fileName, char* path)
{
    // Make space for the new file name, including a '\0' and a potential '/'
    int newFileNameLen = strlen(path) + strlen(fileName) + 2;
    char* newFileName = malloc(sizeof(char) * newFileNameLen);
    strcpy(newFileName, path);

    // Check to see if path has a trailing '/'
    //  If not, add one
    if (strlen(path)) {
        if (path[strlen(path) - 1] != '/') {
            strcat(newFileName, "/");
        }
    }
    strcat(newFileName, fileName);

    return newFileName;
}

// If this function is called in the parent, it will be using cmdS (Singular)
// Which will just replace the occurence of {} in the stdout, stdin fileNames
// With copies as the parent must copy this data and not overwrite
//
// If the function is called in the child, cmdM will be used (Multiple)
// The child does not need to copy anything as it altready has its own copy
char* substitute_fileName(char** cmdM, char* cmdS, char* fileName)
{
    if (!cmdM) {
        // Makes the total string one character shorter as {} will be taken out
        // And '\0' will be added
        if (cmdS == NULL) {
            return NULL;
        }

        char* newCmdS = init_cmdS(cmdS, strlen(fileName));

        if (newCmdS == NULL) {
            newCmdS = malloc(sizeof(char) * strlen(cmdS));
            strcpy(newCmdS, cmdS);
            return newCmdS;
        }

        char* rCmdS = cmdS;
        int index = 0;
        int rIndex = 0;

        while (cmdS[index]) {
            if (cmdS[index] == '{' && cmdS[index + 1] == '}') {
                cmdS[index] = '\0';
                if (!index) {
                    strcpy(newCmdS, rCmdS);
                } else {
                    strcat(newCmdS, rCmdS);
                }

                strcat(newCmdS, fileName);
                cmdS[index] = '{';
                rCmdS += (rIndex + 2);
                index += 1;
                rIndex = 0;
            }

            index++;
            rIndex++;
        }

        strcat(newCmdS, rCmdS);

        return newCmdS;

    } else {
        int index = 0;
        // Loop through each string and treat them as a singular cmd
        while (cmdM[index] != NULL) {
            cmdM[index] = substitute_fileName(NULL, cmdM[index], fileName);
            index++;
        }

        return NULL;
    }
}

char* init_cmdS(char* cmdS, int fileNameLen)
{
    int index = 0;
    int delimiterCount = 0;
    int cmdSLen = 0;
    char* newCmdS;

    while (cmdS[index]) {
        if (cmdS[index] == '{' && cmdS[index + 1] == '}') {
            delimiterCount++;
            index++;
        }

        index++;
    }

    // Adds length of number of {} minus 2 files lengths and one extra char
    // for '\0'

    if (delimiterCount == 0) {
        return NULL;
    }

    cmdSLen = delimiterCount * (fileNameLen - 2) + strlen(cmdS) + 1;
    newCmdS = malloc(sizeof(char) * cmdSLen);
    memset(newCmdS, 0, sizeof(char) * cmdSLen);

    return newCmdS;
}
