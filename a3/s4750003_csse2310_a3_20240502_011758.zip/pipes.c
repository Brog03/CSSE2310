#include "pipes.h"
#include "error.h"

int*** init_pipe_array(int numPipes, int numFiles)
{

    if (numPipes == 0) {
        return NULL;
    }

    int*** pipes = malloc(sizeof(int**) * numFiles);

    for (int i = 0; i < numFiles; i++) {
        pipes[i] = malloc(sizeof(int*) * numPipes);
        for (int j = 0; j < numPipes; j++) {
            pipes[i][j] = malloc(sizeof(int) * 2);
            pipe(pipes[i][j]);
        }
    }

    return pipes;
}

void close_pipes(int*** pipes, int data[4])
{
    int numPipes = data[0];
    int childNum = data[1];
    int numFiles = data[2];
    int fileNum = data[3];

    if (pipes == NULL) {
        return;
    }

    if (childNum < 0) {
        for (int i = 0; i < numFiles; i++) {
            for (int j = 0; j < numPipes; j++) {
                close(pipes[i][j][RDFD]);
                close(pipes[i][j][WRFD]);
            }
        }

    } else {
        int** currentPipe = pipes[fileNum];
        if (childNum == 0) {
            dup2(currentPipe[0][WRFD], STDOUT_FILENO);

        } else if (childNum == numPipes) {
            dup2(currentPipe[childNum - 1][RDFD], STDIN_FILENO);

        } else if (numPipes != 1) {
            dup2(currentPipe[childNum - 1][RDFD], STDIN_FILENO);

            dup2(currentPipe[childNum][WRFD], STDOUT_FILENO);
        }

        data[1] = -1;
        data[3] = -1;
        close_pipes(pipes, data);
    }
}

void free_pipes(int*** pipes, int data[4])
{
    int numPipes = data[0];
    int childNum = data[1];
    int numFiles = data[2];

    if (pipes == NULL) {
        return;
    }

    if (childNum < 0) {
        if (numFiles > 1) {
            for (int i = 0; i < numFiles; i++) {
                for (int j = 0; j < numPipes; j++) {
                    free(pipes[i][j]);
                }
                free(pipes[i]);
            }
            free(pipes);

        } else {
            for (int i = 0; i < numPipes; i++) {
                free(pipes[0][i]);
            }

            free(pipes[0]);
            free(pipes);
        }
    }
}

void execute_command(char** cmd, char* fileName)
{
    execvp(cmd[0], cmd);
    fflush(stdout);
    fprintf(stderr, ERR_EXE, cmd[0], fileName);
    exit(10);
}
