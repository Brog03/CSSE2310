#include "inc.h"

#ifndef DIRECTORY_H_
#define DIRECTORY_H_

struct pArgv {
    char path[200];
    char** fileList;
    int numFiles;

    bool stats;
    bool allfiles;
    bool parallel;
};

int filter(const struct dirent* dir);
int read_dir(struct pArgv* newArgv);

char* add_path_to_fileName(char* fileName, char* path);
char* substitute_fileName(char** cmdM, char* cmdS, char* fileName);
char* init_cmdS(char* cmdS, int fileNameLen);

#endif
