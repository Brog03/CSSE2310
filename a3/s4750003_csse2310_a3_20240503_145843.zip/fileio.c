#include "fileio.h"
#include "error.h"
#include "inc.h"

long init_iofp(char* newStdin, char* newStdout, char* currentFile)
{
    int newStdinFp = 0;
    int newStdoutFp = 0;

    if (newStdin) {
        newStdinFp = open(newStdin, O_RDONLY);

        if (newStdinFp <= 0) {
            fprintf(stderr, ERR_STDIN, newStdin, currentFile);
            newStdinFp = -1;
        }
    }

    if (newStdout) {
        newStdoutFp
                = open(newStdout, O_WRONLY | O_CREAT | O_TRUNC, STDOUT_PERM);

        if (newStdoutFp <= 0) {
            fprintf(stderr, ERR_STDOUT, newStdout, currentFile);
            newStdoutFp = -1;
        }
    }

    return ((long)newStdoutFp << F_FD_SIZE) + newStdinFp;
}

int extract_iofp(long fps, int fp)
{
    int file = 0;
    if (fp == STDIN_FILENO) {
        file = fps & F_STDIN_ENC;
    } else if (fp == STDOUT_FILENO) {
        file = (fps & F_STDOUT_ENC) >> F_FD_SIZE;
    }

    return file;
}

void redirect_iofp(int newStdinFp, int newStdoutFp, int childNum, int numChild)
{
    if (newStdinFp) {
        if (!childNum) {
            dup2(newStdinFp, STDIN_FILENO);
            close(newStdinFp);
        }
    }

    if (newStdoutFp) {
        if (childNum == (numChild - 1)) {
            dup2(newStdoutFp, STDOUT_FILENO);
            close(newStdoutFp);
        }
    }
}
